package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketDAOImpl implements TicketDAO{
	private static Map<String,String> ticketCategory=new HashMap<String,String>();

	private static Map<String,TicketBean> ticketLog=new HashMap<String,TicketBean >();
	public static Map<String,String> getTicketCategoryEntries(){
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		return ticketCategory;
	}
	@Override
	public int raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		
		ticketLog.put(ticketBean.getTicketNo(), ticketBean);
		String s=ticketBean.getTicketNo();
		int i=Integer.parseInt(s);
		return i;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		 List<TicketCategory> l1=new ArrayList<TicketCategory>();
		 Map<String, String> m1=TicketDAOImpl.getTicketCategoryEntries();
		 int i=1;
		for (Map.Entry<String, String> entry : m1.entrySet()) {
			TicketCategory tc=new TicketCategory(entry.getKey(), entry.getValue());
			l1.add(tc);
			
		}
		
		return l1;
	}

}
